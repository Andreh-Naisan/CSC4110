from logging import root
import tkinter
import turtle
import tkinter as tk
import random
import time
from tkinter import scrolledtext, messagebox
import os
import sys

#added by andre (accept_eula and def deny_eula)
#accpet eula
def accept_eula():
    global eula_accepted
    eula_accepted = True
    root.destroy()

#deny eula
def deny_eula():
    tkinter.messagebox.showinfo("EULA Denied", "You have denied the EULA.")
    root.destroy()
    sys.exit(0)
    
if getattr(sys, 'frozen', False):
    CURRENT_DIR = os.path.dirname(sys.executable)
else:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

EULA_AGREEMENT_TEXT = os.path.join(CURRENT_DIR, "eulaagreement.txt")

#This is to make a declared variable for the eula agreement 
def agreement():
    with open(EULA_AGREEMENT_TEXT, "r") as file:
        eula_agreement = file.read()

    global root #added by andre

    root = tk.Tk()
    #This is for the title of the eula agreement 
    root.title("EULA Agreement")
    #This is for the width and height of the eula agreement window 
    text_widget = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=100, height=40)  
    text_widget.insert('1.0', eula_agreement)
    #This is to disable the user from editing the user agreement 
    text_widget.config(state='disabled')  
    text_widget.pack()

    #buttons added by andre
    accept_button = tk.Button(root, text="Accept and proceed", command=accept_eula)
    accept_button.pack()

    deny_button = tk.Button(root, text="Deny and Exit", command=deny_eula)
    deny_button.pack()


    root.mainloop()
#This is for the eula agreement that is going to show up 
agreement()


# Create a turtle screen for the animation
screen = turtle.Screen()
screen.setworldcoordinates(-500, -500, 500, 500)
screen.tracer(0, 0)

# Create a turtle for drawing bars
drawing_turtle = turtle.Turtle()
drawing_turtle.speed(0)
drawing_turtle.hideturtle()

# Function to draw a bar
def draw_bar(x, y, w, h):
    drawing_turtle.up()
    drawing_turtle.goto(x, y)
    drawing_turtle.seth(0)
    drawing_turtle.down()
    drawing_turtle.begin_fill()
    drawing_turtle.fd(w)
    drawing_turtle.left(90)
    drawing_turtle.fd(h)
    drawing_turtle.left(90)
    drawing_turtle.fd(w)
    drawing_turtle.left(90)
    drawing_turtle.fd(h)
    drawing_turtle.left(90)
    drawing_turtle.end_fill()

# Function to draw the bars
def draw_bars(v, n, currenti=-1, currentj=-1):
    drawing_turtle.clear()
    x = -400
    w = 800 / n
    for i in range(n):
        if i == currenti:
            drawing_turtle.fillcolor('red')
        elif i == currentj:
            drawing_turtle.fillcolor('blue')
        else:
            drawing_turtle.fillcolor('gray')
        draw_bar(x, -400, w, v[i])
        x += w
    screen.update()

# Function to partition
def partition(v, x, y):
    p = random.randint(x, y)
    v[p], v[y] = v[y], v[p]
    pivot = v[y]
    i, j = x, y - 1
    while i <= j:
        while v[i] <= pivot and i <= j:
            draw_bars(v, n, i, j)
            i += 1
        while v[j] > pivot and j >= i:
            draw_bars(v, n, i, j)
            j -= 1
        if i < j:
            draw_bars(v, n, i, j)
            v[i], v[j] = v[j], v[i]
    v[i], v[y] = v[y], v[i]
    draw_bars(v, n, i, y)
    return i

# Function for quick sort
def quick_sort(v, x, y):
    if x >= y:
        return
    m = partition(v, x, y)
    quick_sort(v, x, m - 1)
    quick_sort(v, m + 1, y)

# Initialize values and perform quick sort
n = 50
v = [0] * n
for i in range(n):
    v[i] = random.randint(1, 800)

t1 = time.time()
quick_sort(v, 0, n - 1)
t2 = time.time()

print('elapsed time=', t2 - t1)

# Start the tkinter main loop -> Andre replaced main loop with turtle done
turtle.done()



