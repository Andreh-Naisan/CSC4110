#Start date 10/9/2023
#started by Andre N

import os
import random
import sys
import tkinter
from tkinter import scrolledtext
from tkinter import messagebox
from tkinter import simpledialog
import turtle
import math

#eula directory path
if getattr(sys, 'frozen', False):
    CURRENT_DIR = os.path.dirname(sys.executable)
else:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

EULA_AGREEMENT_TEXT = os.path.join(CURRENT_DIR, "eulaagreement.txt")


#show dialogue box to enter limit of prime nums 0 to user input
def get_limit():
    limit = simpledialog.askinteger("Enter Limit", "Enter the limit for prime numbers spiral:")
    return limit


#check if prime number
def is_prime(n):
    if n <= 1:
        return False
    if n <= 3:
        return True
    if n % 2 == 0 or n % 3 == 0:
        return False
    i = 5
    while i * i <= n:
        if n % i == 0 or n % (i + 2) == 0:
            return False
        i += 6
    return True

# Prime numbers using polar coordinates
def draw_spiral_of_primes(limit):
    screen = turtle.Screen()
    screen.setup(width=1000, height=850)

    turtle.bgcolor("black")
    turtle.pencolor(random.choice(['red', 'green', 'pink', 'yellow', 'orange', 'white']))
    turtle.speed(0)
    turtle.delay(0)
    turtle.penup()
    turtle.pensize(1)

    angle = 0
    radius = 20
    scale_factor = 1.0
    prev_x, prev_y = None, None

    for num in range(1, limit + 1):
        if is_prime(num):
            x = radius * scale_factor * math.cos(math.radians(angle))
            y = radius * scale_factor * math.sin(math.radians(angle))

            if abs(x) > screen.window_width() / 2 or abs(y) > screen.window_height() / 2:
                scale_factor *= 0.8

            turtle.goto(x, y)
            turtle.pendown()
            turtle.dot()
            turtle.penup()

            if prev_x is not None and prev_y is not None:
                turtle.goto(prev_x, prev_y)
                turtle.pendown()
                turtle.goto(x, y)
                turtle.penup()
                turtle.goto(x, y - 15)  
                turtle.pendown()
                turtle.pencolor(random.choice(['red', 'green', 'pink', 'yellow', 'orange', 'white']))
                turtle.write(str(num), align="center", font=("Arial", 12, "normal"))
                turtle.penup()
                turtle.pencolor(random.choice(['red', 'green', 'pink', 'yellow', 'orange', 'white']))

            prev_x, prev_y = x, y

           

        angle += 10
        radius += 2

    turtle.update()
    turtle.hideturtle()
    turtle.done()

    

#load eula
def load_eula_content(filename):
    with open(filename, 'r') as file:
        return file.read()

#accpet eula
def accept_eula():
    global eula_accepted
    eula_accepted = True
    root.destroy()

#deny eula
def deny_eula():
    tkinter.messagebox.showinfo("EULA Denied", "You have denied the EULA.")
    root.destroy()
    sys.exit()

#display eula
def display_eula(content):
    global root
    root = tkinter.Tk()
    root.title("EULA Agreement")

    text_area = scrolledtext.ScrolledText(root, wrap=tkinter.constants.WORD, width=80, height=20)
    text_area.insert(tkinter.INSERT, content)
    text_area.configure(state='disabled')
    text_area.pack(padx=10, pady=10)

    accept_button = tkinter.Button(root, text="Accept and proceed", command=accept_eula)
    accept_button.pack()

    deny_button = tkinter.Button(root, text="Deny and Exit", command=deny_eula)
    deny_button.pack()

    root.mainloop()

if __name__ == "__main__":
    eula = load_eula_content(EULA_AGREEMENT_TEXT)
    display_eula(eula)

    limit = get_limit()

    if limit is not None:
        draw_spiral_of_primes(limit)
        



#End date ?/?/?
#Ended by ?????,Andre N
 