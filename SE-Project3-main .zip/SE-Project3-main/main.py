import sys
import tkinter as tk
from tkinter import ttk, Text, Label
from tkinter import messagebox, Text, Label
import json
from tkinter import simpledialog
import tkinter
from tkinter import scrolledtext
import uuid
from datetime import datetime
import os

#eula directory path
if getattr(sys, 'frozen', False):
    CURRENT_DIR = os.path.dirname(sys.executable)
else:
    CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

EULA_AGREEMENT_TEXT = os.path.join(CURRENT_DIR, "eulaagreement.txt")

#load eula
def load_eula_content(filename):
    with open(filename, 'r') as file:
        return file.read()

#accpet eula
def accept_eula():
    global eula_accepted
    eula_accepted = True
    root.destroy()

#deny eula
def deny_eula():
    tkinter.messagebox.showinfo("EULA Denied", "You have denied the EULA.")
    root.destroy()
    sys.exit()

#display eula
def display_eula(content):
    global root
    root = tkinter.Tk()
    root.title("EULA Agreement")

    text_area = scrolledtext.ScrolledText(root, wrap=tkinter.constants.WORD, width=80, height=20)
    text_area.insert(tkinter.INSERT, content)
    text_area.configure(state='disabled')
    text_area.pack(padx=10, pady=10)

    accept_button = tkinter.Button(root, text="Accept and proceed", command=accept_eula)
    accept_button.pack()

    deny_button = tkinter.Button(root, text="Deny and Exit", command=deny_eula)
    deny_button.pack()

 

# Honestly i couldn't think of a better way to handle the horrible amount of
# dependencies each function would have as we are going linearly through
# the application instead of horizontally, so the mainframe stuff will be global
window = tk.Tk()
window.title("Intergalactic POS system")
window.geometry("500x400")
main_frame = tk.Frame(window)
main_frame.pack(fill="both", expand=True)

# Frames and their STATIC BUTTONS/ELEMENTS we will be using initialized here
# PLANET FRAME
planet_frame = tk.Frame(main_frame)
# Ribbon Frame
ribbon_frame = ttk.Frame(main_frame)
ribbon_frame.pack(fill="x", side="top")

#ribbon Buttons
menu_button = ttk.Button(
    ribbon_frame, text="Main Menu", command=lambda: planet_window()
)
menu_button.pack(side=tk.LEFT, padx=10)

shipping_estimate_button = ttk.Button(
    ribbon_frame, text="Shipping Estimate", command=lambda: open_shipping_estimate()
)
shipping_estimate_button.pack(side=tk.LEFT, padx=10)

lookup_order_button = ttk.Button(
    ribbon_frame, text="Lookup Order", command=lambda: lookup_order()
)
lookup_order_button.pack(side=tk.LEFT, padx=10)

cart_button = ttk.Button(ribbon_frame, text="Cart", command=lambda: cart_window())
cart_button.pack(side=tk.LEFT, padx=20)
# the buttons of the planet frame are dynamically created on the page

# CART FRAME
cart_frame = tk.Frame(main_frame)
text_area = Text(cart_frame, height=20, width=50)
text_area.pack(padx=10, pady=10)
shop_more_button = tk.Button(
    cart_frame, text="Shop More", command=lambda: planet_window()
)
shop_more_button.pack(side=tk.LEFT, padx=20, pady=10)
checkout_button = tk.Button(
    cart_frame, text="Checkout", command=lambda: checkout_window()
)
checkout_button.pack(side=tk.RIGHT, padx=20, pady=10)

# CHECKOUT FRAME
checkout_frame = tk.Frame(main_frame)
checkout_label = Label(checkout_frame, text="Select a delivery option below")
checkout_label.pack(pady=10)

# RECEIPT FRAME
receipt_frame = tk.Frame(main_frame)
receipt_label = Label(receipt_frame, text="Below is your final receipt, enjoy!")
text_area_receipt = Text(receipt_frame, height=20, width=50)
text_area_receipt.pack(padx=10, pady=10)


# below are global variables we will be using
# planets and their minerals
planets = [
    "Mercury",
    "Venus",
    "Earth",
    "Mars",
    "Jupiter",
    "Saturn",
    "Uranus",
    "Neptune",
]



planet_minerals = {
    "Mercury": ["Iron", "Silicate"],
    "Venus": ["Copper", "Aluminum"],
    "Earth": ["Gold", "Silver"],
    "Mars": ["Platinum"],
    "Jupiter": ["Helium", "Hydrogen"],
    "Saturn": ["Helium", "Hydrogen", "Titanium"],
    "Uranus": ["Helium", "Hydrogen", "Uranium"],
    "Neptune": ["Helium", "Hydrogen", "Ice"],
}

# Where we are incrementing our total amounts to keep track
# for PoS purposes
planet_mineral_counts = {
    planet: {mineral: 0 for mineral in minerals}
    for planet, minerals in planet_minerals.items()
}

delivery_options = [
    "Express: 1 week\nshipping Cost: 25 million credits",
    "Economy: 2 months\nshipping Cost: 10 million credits",
]
delivery_option_selected = ""


def planet_window():
    cart_frame.pack_forget()
    planet_frame.pack(fill="both", expand=True)

    # This below is to clear the existing buttons and generating
    # new ones
    for widget in planet_frame.winfo_children():
        widget.destroy()

    def update_mineral_count(planet, mineral):
        planet_mineral_counts[planet][mineral] += 1
        print(f"{planet_mineral_counts}")

    def select_planet(planet):
        popup = tk.Toplevel(window)
        popup.title(f"{planet} Minerals")

        for mineral in planet_minerals[planet]:
            btn = tk.Button(
                popup,
                text=mineral,
                height=5,
                width=10,
                command=lambda m=mineral: update_mineral_count(planet, m),
            )
            btn.pack(side=tk.LEFT, padx=10, pady=5)

        close_btn = tk.Button(
            popup, text="Close", height=5, width=10, command=popup.destroy
        )
        close_btn.pack(side=tk.LEFT, pady=10)

    # create rows with 4 buttons each
    num_buttons_per_row = 4
    for i in range(0, len(planets), num_buttons_per_row):
        row_buttons = planets[i : i + num_buttons_per_row]

        row_frame = tk.Frame(planet_frame)
        row_frame.pack(side=tk.TOP, pady=10)

        for planet in row_buttons:
            #load image for the planet button
            img_path = os.path.join(CURRENT_DIR, 'images', f'{planet.lower()}.gif')  #this will your path to the images folder
            img = tk.PhotoImage(file=img_path)

            button = tk.Button(
                row_frame,
                text=planet,
                image=img,
                compound=tk.BOTTOM,
                height=100,
                width=100,
                command=lambda p=planet: select_planet(p),
            )
            button.image = img
            button.pack(side=tk.LEFT, padx=10)

def cart_window():
    planet_frame.pack_forget()

    cart_popup = tk.Toplevel(window)
    cart_popup.title("Cart")

    cart_frame = tk.Frame(cart_popup)
    cart_frame.pack(fill="both", expand=True)

    text_area = Text(cart_frame, height=20, width=50)

    text_area.delete("1.0", tk.END)

    for planet, minerals in planet_mineral_counts.items():
        text_area.insert(tk.END, f"{planet}:\n")
        for mineral, count in minerals.items():
            text_area.insert(tk.END, f"  {mineral}: {count}\n")
        text_area.insert(tk.END, "\n")

    text_area.pack(padx=10, pady=10)

    shop_more_button = tk.Button(
        cart_frame, text="Shop More", command=lambda: shop_more(cart_popup)
    )
    shop_more_button.pack(side=tk.LEFT, padx=20, pady=10)

    checkout_button = tk.Button(
        cart_frame, text="Checkout", command=lambda: checkout_window(cart_popup)
    )
    checkout_button.pack(side=tk.RIGHT, padx=20, pady=10)

    cart_popup.mainloop()


def shop_more(previous_window):
    #Shop More will go back to main menu
    previous_window.destroy()
    planet_window()


def checkout_window(previous_window):
    global delivery_option_selected

    previous_window.withdraw()

    checkout_popup = tk.Toplevel(window)
    checkout_popup.title("Checkout")

    checkout_frame = tk.Frame(checkout_popup)
    checkout_frame.pack(fill="both", expand=True)

    # record what they have selected into delivery_option_selected
    def select_delivery(p):
        global delivery_option_selected
        delivery_option_selected = p
        temptext = "Selected Delivery option: " + delivery_option_selected
        checkout_label.config(text=temptext)
    # show the delivery_options
    for delivery_option in delivery_options:
        button = tk.Button(
            checkout_frame,
            text=delivery_option,
            height=5,
            width=25,
            command=lambda p=delivery_option: select_delivery(p),
        )
        button.pack(side=tk.TOP, padx=10, pady=10)

    def finalize_checkout(checkout_popup):
        # Generate a unique receipt ID
        receipt_id = generate_receipt_id()

        # Create a sorted list of items for the receipt
        sorted_items = sort_items(planet_mineral_counts)

        #Create the receipt dictionary
        receipt_data = {
            "id": receipt_id,
            "items": sorted_items,
            "delivery_option": delivery_option_selected,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            
        }

        # Save the receipt to the JSON file
        save_receipt(receipt_data)

        # This is to hide the checkout window
        checkout_popup.withdraw()
        receipt_window(checkout_popup, receipt_data)

    receipt_button = tk.Button(
        checkout_frame,
        height=5,
        width=10,
        text="Finalize",
        command=lambda: finalize_checkout(checkout_popup),
    )
    receipt_button.pack(side=tk.TOP, padx=10, pady=10)


def receipt_window(previous_window, receipt_data):
    receipt_popup = tk.Toplevel(window)
    receipt_popup.title("Receipt")

    receipt_frame = tk.Frame(receipt_popup)
    receipt_frame.pack(fill="both", expand=True)

    text_area_receipt = Text(receipt_frame, height=20, width=50)
    text_area_receipt.pack(padx=10, pady=10)

    text_area_receipt.delete("1.0", tk.END)
    for planet, minerals in planet_mineral_counts.items():
        text_area_receipt.insert(tk.END, f"{planet}:\n")
        for mineral, count in minerals.items():
            text_area_receipt.insert(tk.END, f"  {mineral}: {count}\n")
        text_area_receipt.insert(tk.END, "\n")

    text_area_receipt.insert(
        tk.END, f"Delivery Option: {receipt_data['delivery_option']}\n"
    )
    text_area_receipt.insert(tk.END, f"Order ID: {receipt_data['id']}\n")

    shop_more_button = tk.Button(
        receipt_frame, text="Shop More", command=lambda: shop_more(receipt_popup)
    )
    shop_more_button.pack(side=tk.BOTTOM, pady=10)


def shop_more(previous_window):
    # This function is called when the "Shop More" button is clicked in the cart window
    previous_window.destroy()
    planet_window()


def open_shipping_estimate():
    shipping_estimate_window()


shipping_costs = {
    "Mercury": {
        "Express": 50,
        "Economy": 30,
    },
    "Venus": {
        "Express": 40,
        "Economy": 30,
    },
    "Earth": {
        "Express": 25,
        "Economy": 10,
    },
    "Mars": {
        "Express": 15,
        "Economy": 10,
    },
    "Jupiter": {
        "Express": 35,
        "Economy": 20,
    },
    "Saturn": {
        "Express": 45,
        "Economy": 30,
    },
    "Uranus": {
        "Express": 70,
        "Economy": 50,
    },
    "Neptune": {
        "Express": 80,
        "Economy": 60,
    },
}

def calculate_shipping_estimate():
    global delivery_option_selected
    
def shipping_estimate_window():
    global selected_address_var

    shipping_window = tk.Toplevel(window)
    shipping_window.title("Shipping Estimate")
    shipping_window.geometry("300x300")

    address_label = Label(shipping_window, text="Shipping Address:")
    address_label.pack(pady=5)

    selected_address_var = tk.StringVar()
    selected_address_var.set(0)

    addresses = [
        "Mercury",
        "Venus",
        "Earth",
        "Mars",
        "Jupiter",
        "Saturn",
        "Uranus",
        "Neptune",
    ]
    for address in addresses:
        radio_button = tk.Radiobutton(
            shipping_window, text=address, variable=selected_address_var, value=address
        )
        radio_button.pack()

    total_label = tk.Label(shipping_window, text="Total Amount: 0 credits")
    total_label.pack(pady=5)

    def update_total_amount():
        express_cost = shipping_costs.get(selected_address_var.get(), {}).get("Express", 0)
        economy_cost = shipping_costs.get(selected_address_var.get(), {}).get("Economy", 0)
        total_label.config(text=f"Express Shipping Cost: {express_cost} million credits\nEconomy Shipping Cost: {economy_cost} million credits")

    selected_address_var.trace_add("write", lambda *args: update_total_amount())


def generate_receipt_id():
    # Generate a unique receipt ID
    return str(uuid.uuid4())[:8]


def sort_items(items):
    # Sort items based on a chosen criterion
    sorted_items = []
    for planet, minerals in items.items():
        for mineral, count in minerals.items():
            if count > 0:
                sorted_items.append(
                    {"planet": planet, "mineral": mineral, "count": count}
                )
    return sorted(sorted_items, key=lambda x: x["mineral"])


def save_receipt(receipt_data):
    # Read existing data
    try:
        with open(os.path.join(CURRENT_DIR, 'receipts.json'), "r") as file:
            data = json.load(file)
    except FileNotFoundError:
        data = []

    # Append new data
    data.append(receipt_data)

    # Write data back to file
    with open(os.path.join(CURRENT_DIR, 'receipts.json'),"w",) as file: #this will your path to the json file 
        json.dump(data, file, indent=4)

    # the saving of the planet_mineral_counts and delivery option into a json file goes here

    # lookup button goes here
    # this button will bring up a popup that lets you sort through previous receipts
    # if you select one, have it update the text_area_receipt

    return

def lookup_order():
    order_id = simpledialog.askstring("Lookup Order", "Enter Order ID:")

    if not order_id:
        return

    order_details = fetch_order_details(order_id)

    if not order_details:
        messagebox.showinfo("Order Not Found", f"No order found with ID {order_id}")
        return

    order_popup = tk.Toplevel(window)
    order_popup.title(f"Order Details - Order ID: {order_id}")

    order_frame = tk.Frame(order_popup)
    order_frame.pack(fill="both", expand=True)

    text_area_order = Text(order_frame, height=20, width=50)
    text_area_order.pack(padx=10, pady=10)

    display_order_details(order_details, text_area_order)

    close_button = tk.Button(
        order_frame, text="Close", command=lambda: order_popup.destroy()
    )
    close_button.pack(side=tk.BOTTOM, pady=10)


def fetch_order_details(order_id):
    try:
        with open(os.path.join(CURRENT_DIR, 'receipts.json'), "r") as file:
            data = json.load(file)
    except FileNotFoundError:
        return None

    print("Loaded data:", data)

    #search for the order withorder ID
    for order in data:
        print("Checking order:", order)
        if order["id"] == order_id:
            return order

    return None

def display_order_details(order_details, text_widget):
    text_widget.delete("1.0", tk.END)

    #display order details 
    text_widget.insert(tk.END, f"Order ID: {order_details['id']}\n")
    text_widget.insert(tk.END, f"Timestamp: {order_details['timestamp']}\n")

    for item in order_details['items']:
        text_widget.insert(
            tk.END, f"Planet: {item['planet']} \nMineral: {item['mineral']} \nCount: {item['count']} units\n"
        )

    text_widget.insert(tk.END, f"Delivery Option: {order_details['delivery_option']}\n")



def main():
    eula = load_eula_content(EULA_AGREEMENT_TEXT)
    display_eula(eula)

    # add frames in global section
    planet_window()
    window.mainloop()


if __name__ == "__main__":
    main()

